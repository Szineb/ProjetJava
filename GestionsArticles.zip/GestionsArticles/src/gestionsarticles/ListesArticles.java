/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionsarticles;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author tatye
 */
public class ListesArticles {
    
//Convertir une entree de type String en un format de date 
    public void ConvertToDate() throws ParseException{
        Scanner sc= new Scanner(System.in);
        String date;
        System.out.println("Entrer date:");
        date=sc.nextLine();
  SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
Date date1= sdf.parse(date);
System.out.println(date1);


}
    
}
