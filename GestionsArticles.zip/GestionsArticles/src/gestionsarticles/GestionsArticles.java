/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionsarticles;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.net.URL;
import java.time.LocalDate;
import java.util.TimeZone;

/**
 *
 * @author tatye
 */
public class GestionsArticles {

    /**
     * @param args the command line arguments
     */
    
   
    public static void main(String[] args) {
       
        ListesArticles a = new ListesArticles();
        a.ConvertToDate();
         
        /*String title,description,rss,author;
        LocalDate datePublication = null;
        URL link = null;
        int inter;
    
        Scanner sc= new Scanner(System.in);
		System.out.println("Saisir Titre:");
		title= sc.nextLine();
		System.out.println("Saisir Description:");
                description=sc.nextLine();
		System.out.println("Saisir Date de publication:");
                LocalDate.parse(sc.nextLine());
                
                System.out.println("Saisir RSS:");
                rss=sc.nextLine();
                System.out.println("Saisir Auteur:");
                author=sc.nextLine();
                System.out.println("Lien");
                String s= sc.nextLine();
                    try {
                      link= new URL(s);
                   } catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
                   // sc.nextLine();
                System.out.println("Saisir Inter:");
                inter=sc.nextInt();
		
		System.out.println("Saisir Auteur:");
		author= sc.nextLine();
        Article article= new Article(title,description,datePublication,rss,author,link,inter);
        System.out.println("Voici Notre liste");
        System.out.println(article.toString());*/
        
    }
    }
    

