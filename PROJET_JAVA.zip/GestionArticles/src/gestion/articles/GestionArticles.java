/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion.articles;

import java.awt.Panel;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author pesawado
 */
public class GestionArticles extends Application {

    //Creation des objets qui seront utilisés dans notre interface graphique
    private TableView tableView = new TableView();
    ArrayList<Article> liste = new ArrayList<>();
    private ImplementationLucene lucene = new ImplementationLucene();//On cree une instance de la classe Implementationlucene
    public static ObservableList<Article> data = FXCollections.observableArrayList(); //On initialise la liste qui contiendra les données du TableView
    public static ObservableList<Article> dataCopie = FXCollections.observableArrayList();//On initialise une autre liste qui contiendra une copie des données du tableView
    private final int FRAME_WIDTH = 1200;
    private final int FRAME_HEIGTH = 600;
    private final String TITLE = "*******GESTION ET ANALYSE DES ARTICLES DE PRESSE*******";
    private TextField filtreTitre = new TextField();
    private TextField filtreDescription = new TextField();
    private TextField filtreAuteur = new TextField();
    private TextField filtreGlobal = new TextField();
    private DatePicker filtreDate1 = new DatePicker();
    private DatePicker filtreDate2 = new DatePicker();
    private Label labelTitre1 = new Label("");
    private Label labelAuteur1 = new Label("");
    private Label labelTexte1 = new Label("");
    private Label labelTitre2 = new Label("");
    private Label labelAuteur2 = new Label("");
    private Label labelTexte2 = new Label("");
    private Button boutonImporter = new Button("IMPORTER");
    private Button boutonExporter = new Button("EXPORTER");
    private Button boutonRequete = new Button("REQUETE");

    @Override
    public void start(Stage primaryStage) { 
        /*Gestion de la section HAUT de la fenetre*/
        
        Label labelFiltreTitre = new Label("FILTRE/TITRE");
        Label labelFiltreDescription = new Label("FILTRE/DESCRIPTION");
        Label labelFiltreAuteur = new Label("FILTRE/AUTEUR");
        Label labelFiltreGlobal = new Label("FILTRE GENERAL");
        Label labelFiltreDate1 = new Label("DATE >");
        Label labelFiltreDate2 = new Label("DATE <");
        
        GridPane conteneurHaut = new GridPane();//On utilise un Gridpane pour placer les éléments dans la section HAUT
        conteneurHaut.add(boutonImporter, 0, 0, 1, 2);
        conteneurHaut.add(boutonExporter, 1, 0, 1, 2);
        conteneurHaut.add(boutonRequete, 2, 0, 1, 2);
        conteneurHaut.add(labelFiltreTitre, 3, 0);
        conteneurHaut.add(filtreTitre, 3, 1);
        conteneurHaut.add(labelFiltreDescription, 4, 0);
        conteneurHaut.add(filtreDescription, 4, 1);
        conteneurHaut.add(labelFiltreAuteur, 5, 0);
        conteneurHaut.add(filtreAuteur, 5, 1);
        conteneurHaut.add(labelFiltreGlobal, 6, 0);
        conteneurHaut.add(filtreGlobal, 6, 1);
        conteneurHaut.add(labelFiltreDate1, 7, 0);
        conteneurHaut.add(filtreDate1, 7, 1);
        conteneurHaut.add(labelFiltreDate2, 8, 0);
        conteneurHaut.add(filtreDate2, 8, 1);
        boutonExporter.setDisable(true);//On désactive les boutons EXPORTER et REQUETE a la creation de la fenetre; 
        boutonRequete.setDisable(true);//Ils seront reactivés lors de l'importation de données

        /* Gestion de la partie MILIEU de la fenetre: Gestion du TableView*/
        
        TableColumn numCol = new TableColumn("N°");//On cree les colonnes du TableView
        TableColumn titleCol = new TableColumn("TITLE");
        TableColumn descriptionCol = new TableColumn("DESCRIPTION");
        TableColumn datePublicationCol = new TableColumn("DATE");
        TableColumn rssCol = new TableColumn("RSS");
        TableColumn authorCol = new TableColumn("AUTEUR");
        TableColumn linkCol = new TableColumn("LINK");
        TableColumn interCol = new TableColumn("INTER");
        //On ajoute une colonne Numero qui affichera des numeros de lignes
        numCol.setCellValueFactory(new Callback<CellDataFeatures<Article, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(CellDataFeatures<Article, String> p) {
                return new ReadOnlyObjectWrapper(tableView.getItems().indexOf(p.getValue()) + 1 + "");
            }
        });
        numCol.setSortable(false);
        //Association des noms de colonnes à des champs de la classe Article
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        datePublicationCol.setCellValueFactory(new PropertyValueFactory<>("datePublication"));
        rssCol.setCellValueFactory(new PropertyValueFactory<>("rss"));
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        linkCol.setCellValueFactory(new PropertyValueFactory<>("link"));
        interCol.setCellValueFactory(new PropertyValueFactory<>("inter"));

        //On parametre les tailles des colonnes
        numCol.setPrefWidth(FRAME_WIDTH * 3 / 100);
        numCol.setMaxWidth(FRAME_WIDTH * 4 / 100);
        titleCol.setPrefWidth(FRAME_WIDTH * 10 / 100);
        descriptionCol.setPrefWidth(FRAME_WIDTH * 35 / 100);
        datePublicationCol.setPrefWidth(FRAME_WIDTH * 10 / 100);
        rssCol.setPrefWidth(FRAME_WIDTH * 10 / 100);
        authorCol.setPrefWidth(FRAME_WIDTH * 10 / 100);
        linkCol.setPrefWidth(FRAME_WIDTH * 10 / 100);
        interCol.setPrefWidth(FRAME_WIDTH * 10 / 100);

        /*Gestion de la section BAS de notre fenetre*/
        GridPane conteneurBas = new GridPane();
        //On cree 3 sous section pour notre section BAS
        GridPane conteneurTitre = new GridPane();//Section requete sur le Titre
        GridPane conteneurAuteur = new GridPane();//Section requete sur l'auteur
        GridPane conteneurTexte = new GridPane();//Section requete sur le texte
        conteneurTitre.setPrefWidth(FRAME_WIDTH * 33 / 100);
        conteneurTexte.setPrefWidth(FRAME_WIDTH * 33 / 100);
        conteneurAuteur.setPrefWidth(FRAME_WIDTH * 33 / 100);
        //On place les éléments de ces sous sections
        conteneurTitre.add(labelTitre1, 1, 1);
        conteneurTitre.add(labelTitre2, 1, 2);
        conteneurAuteur.add(labelAuteur1, 1, 1);
        conteneurAuteur.add(labelAuteur2, 1, 2);
        conteneurTexte.add(labelTexte1, 1, 1);
        conteneurTexte.add(labelTexte2, 1, 2);
        //on plce les 3 sous sections dans le conteneur de la section BAS
        conteneurBas.add(conteneurAuteur, 1, 1);
        conteneurBas.add(conteneurTitre, 2, 1);
        conteneurBas.add(conteneurTexte, 3, 1);
        //On ajoute les colonnes au tableView
        tableView.getColumns().addAll(numCol, titleCol, descriptionCol, datePublicationCol, rssCol, authorCol, linkCol, interCol);
        //On ajoute les données
        tableView.setItems(data);
        BorderPane root = new BorderPane();//on cree le conteneur principal
        root.setTop(conteneurHaut);//on place la section HAUT dans le conteneur principal
        root.setCenter(tableView);//on place le tableView dans la Section MILIEU du conteneur principal
        root.setBottom(conteneurBas);//on place la section BAS dans le conteneur principal
        
        //Ecouteurs et Gestion des évènements
        boutonImporter.setOnMouseClicked(new EventHandler<Event>() {//Ecouteur sur le bouton importer
            @Override
            public void handle(Event event) {
                FileChooser fileChooser = new FileChooser();//creation d'une fenetre popup permettant a l'utilisateur de choisir un fichier
                fileChooser.setTitle("Choix du fichier à importer");
                File homeDir = new File(System.getProperty("user.home"));
                fileChooser.setInitialDirectory(homeDir);
                fileChooser.getExtensionFilters().addAll(new ExtensionFilter("CSV Files", "*.csv"));//on filtre les fichiers CSV
                Alert dialog = new Alert(AlertType.INFORMATION);
                dialog.setHeaderText(null);  //No header                                
                File fichier = fileChooser.showOpenDialog(primaryStage);
                if (fichier != null) {//Une fois que le ficier est sélectionné...
                    ListeArticles l = new ListeArticles();//on instancie un objet listeArticle
                    try {
                        ArrayList<Article> liste = new ArrayList<>();
                        liste = (ArrayList<Article>) l.importer(fichier); //on fait appel a la methode importer pour recuperer la liste des articles contenus dans le fichier
        
                        data.addAll(liste);//on ajoute les données importees à la liste du TABLEVIEW
                        dataCopie.addAll(liste);//on ajoute ces données à la deuxieme liste egalement
                        lucene.indexFile(liste);//on indexe le fichier qui vient d'etre importé
                        boutonExporter.setDisable(false);//on reactive les boutons requete et exporter maintenant qu'il y'a des données
                        boutonRequete.setDisable(false);
                        
                        dialog.setTitle("IMPORTATION REUSSIE");//on affiche un Pop-up pour informer du bon deroulement de l'operation
                        dialog.setContentText("Le fichier " + fichier.getName() + " a été importé avec " + liste.size() + " lignes");
                        dialog.showAndWait();
                    } catch (IOException ex) {//En cas d'erreur
                        dialog.setAlertType(AlertType.ERROR);//on informe l'utilisateur de l'echec de l'ouverture du fichier
                        dialog.setContentText("Impossible d'ouvrir le fichier");
                        dialog.showAndWait();
                    }
                }
            }
        });

        boutonExporter.setOnMouseClicked(new EventHandler<Event>() {//Ecouteur sur le bouton exporter
            @Override
            public void handle(Event event) {
                DirectoryChooser dirChooser = new DirectoryChooser();//On affiche une fenetre pop-up permettant à l'utilisateur de choisir le dossier dans lequel faire l'export
                dirChooser.setTitle("Dossier d'enregistrement du fichier");
                File homeDir = new File(System.getProperty("user.home"));//la fenetre se place par defaut au repertoire de l'utilisateur courant
                dirChooser.setInitialDirectory(homeDir);
                File dossier = dirChooser.showDialog(primaryStage);
                Alert dialog = new Alert(AlertType.INFORMATION);
                dialog.setHeaderText(null);
                if (dossier != null) {
                    try {
                        
                        ListeArticles l = new ListeArticles();//On instancie un objet listeArticles
                        boolean result = l.exporter(data.sorted(), dossier);//on fait appel à la méthode exporter pour exporter les données dans le repertoire choisi
                        if(result){
                            dialog.setTitle("EXPORTATION REUSSIE");
                            dialog.setContentText(data.size() + " lignes ont été exportées");
                            dialog.showAndWait();
                        }
                        else
                        {
                            dialog.setAlertType(AlertType.ERROR);//on affiche un pop-up pour informer l'utilisateur de l'echec de l'operation
                            dialog.setContentText("Impossible d'exporter les données dans le dossier indiqué");
                            dialog.showAndWait();
                        }
                        
                    } catch (Exception e) {//En cas d'erreur
                        dialog.setAlertType(AlertType.ERROR);//on affiche un pop-up pour informer l'utilisateur de l'echec de l'operation
                        dialog.setContentText("Impossible d'exporter les données dans le dossier indiqué");
                        dialog.showAndWait();
                    }
                }
            }
        });

        
        boutonRequete.setOnMouseClicked(new EventHandler<Event>() {//Ecouteur sur le bouton requete
            @Override
            public void handle(Event event) {
                //On affiche un pop-up qui permet a l'utilisateur de rentrer le texte à chercher
                TextInputDialog dialog = new TextInputDialog("Entrer le terme ou l'expression à chercher");
                dialog.setTitle("Requete");
                dialog.setHeaderText(null);
                dialog.setContentText("Terme/Expression :");
                Optional<String> motAchercher = null;
                motAchercher = dialog.showAndWait();
                if ((motAchercher != null) && motAchercher.isPresent()) {//Si l'utilisateur a bien entré un mot
                    try {
                        executionRequetes(motAchercher.get());//On execute la requete
                    } catch (Exception e) {//Si aucune donnée n'est trouvé, on notifie l'utilisateur d'une erreur
                        Alert alert = new Alert(AlertType.ERROR, "Erreur dans la construction de la requete", ButtonType.OK);
                    }
                }
            }
        });
        
        //Ecouteurs sur les filtres. 
        //A chaque modification d'un filtre, la methode updateData est appellée, pour mettre a jour les donnees du textview selon les nouveaux criteres
        filtreTitre.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); 
            }
        });
        filtreAuteur.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); 
            }
        });
        filtreDescription.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); 
            }
        });
        filtreGlobal.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); 
            }
        });

        filtreDate1.valueProperty().addListener(new ChangeListener<LocalDate>() {
            @Override
            public void changed(ObservableValue<? extends LocalDate> observable, LocalDate oldValue, LocalDate newValue) {
                updateData();
            }
        });

        filtreDate2.valueProperty().addListener(new ChangeListener<LocalDate>() {
            @Override
            public void changed(ObservableValue<? extends LocalDate> observable, LocalDate oldValue, LocalDate newValue) {
                updateData();
            }
        });

        /*Creation de la Scène*/
        Scene scene = new Scene(root, FRAME_WIDTH, FRAME_HEIGTH);
        primaryStage.setTitle(TITLE);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        
        launch(args);
        

    }

    //Cette methode met a jour les données du tableview en fonction des filtres
    private void updateData() {
        data.clear();//On commence par effacer les donnees
        for (Article a : dataCopie) {//Puis on parcout la copie de la liste, et on recupere les element respectant les criteres
            if (matchesTitle(a) && matchesAuteur(a) && matchesDescription(a) && matchesGlobal(a) && matchesDate1(a) && matchesDate2(a)) {
                data.add(a);
            }
        }
    }
    
    //Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre sur le titre
    private boolean matchesTitle(Article a) {
        String filterString = filtreTitre.getText();
        if (filterString == null || filterString.isEmpty()) {
            return true;
        }
        
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getTitle().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        }
        return false; 
    }
//Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre sur la description
    private boolean matchesDescription(Article a) {
        String filterString = filtreDescription.getText();
        if (filterString == null || filterString.isEmpty()) {
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getDescription().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        }
        return false; 
    }

    //Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre sur l'auteur
    private boolean matchesAuteur(Article a) {
        String filterString = filtreAuteur.getText();
        if (filterString == null || filterString.isEmpty()) {
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getAuthor().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        }
        return false; // Does not match
    }

    //Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre general
    private boolean matchesGlobal(Article a) {
        String filterString = filtreGlobal.getText();
        if (filterString == null || filterString.isEmpty()) {
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.toString().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        }
        return false; // Does not match
    }

    //Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre1 sur la date
    private boolean matchesDate1(Article a) {
        LocalDate filterDate = filtreDate1.getValue();
        if (filterDate == null) {
            return true;
        }
        if (filterDate.isBefore(a.getDatePublication().toLocalDate())) {
            return true;
        }
        return false;
    }
    
    //Cette methode permet de verifier qu'un element de la liste des articles respecte les criteres du filtre2 sur la date
    private boolean matchesDate2(Article a) {
        LocalDate filterDate = filtreDate2.getValue();
        if (filterDate == null) {
            return true;
        }
        if (filterDate.isAfter(a.getDatePublication().toLocalDate())) {
            return true;
        }
        return false;
    }

    //Cette methode permet d'executer des requetes avec lucene et d'en afficher les resultats sur la fenetre
    private void executionRequetes(String motCle) {
        labelAuteur1.setText("RECHERCHE PARMI LES AUTEURS");
        labelTexte1.setText("RECHERCHE DANS LE TEXTE");
        labelTitre1.setText("RECHERCHE DANS LES TITRES");
        labelAuteur2.setText(lucene.frequence("author", motCle));
        labelTitre2.setText(lucene.frequence("titre", motCle));
        labelTexte2.setText(lucene.frequence("contenu", motCle));
    }

}
