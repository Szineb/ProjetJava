/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion.articles;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.codecs.TermStats;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.misc.HighFreqTerms;
import org.apache.lucene.misc.HighFreqTerms.DocFreqComparator;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.search.spans.SpanTermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;

/**
 *
 * @author Nico
 */
public class ImplementationLucene {

    private Analyzer analyzer;
    private IndexWriter writer;
    private IndexSearcher indexSearcher;
    private Path indexDirectory;
    private Directory fsDirectory;
    private DirectoryReader reader;

    //Constructeur
    public ImplementationLucene() {
        analyzer = new StandardAnalyzer();//on initialise l'Analyzer       
        try {
            indexDirectory = new File(System.getProperty("user.home")).toPath();//on initialise l'index en le creant dans le repertoire de l'utilisateur courant
            fsDirectory = FSDirectory.open(indexDirectory);
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);//Configuration de l'Analyzer
            iwc.setCommitOnClose(true);
            iwc.setOpenMode(OpenMode.CREATE);
            writer = new IndexWriter(fsDirectory, iwc);
            reader = DirectoryReader.open(fsDirectory);// on cree le DirectoryReader
            indexSearcher = new IndexSearcher(reader);//On cree l'IndewSearcher
             
        } catch (IOException ex) {
            System.out.println("Impossible d'initialiser l'index");
        }
    }

    //Cette méthode permet de convertir un objet article en objet Document qui sera indexé
    private Document articleToDocument(Article article) throws IOException {
        Document document = new Document();
        FieldType fieldType1 = new FieldType();//On cree un premier type de champ qui sera stoké
        fieldType1.setStored(true);
        fieldType1.setIndexOptions(IndexOptions.DOCS_AND_FREQS);
        fieldType1.setTokenized(true);
        FieldType fieldType2 = new FieldType();
        fieldType2.setStored(false);//on cree un deuxieme type de champ qui lui ne sera pas stocké
        fieldType2.setIndexOptions(IndexOptions.DOCS_AND_FREQS);
        fieldType2.setTokenized(true);
        //On indexe 3 champs en tous
        Field fieldTitre = new Field("titre", article.getTitle(), fieldType1);// Le titre
        Field fieldAuthor = new Field("author", article.getAuthor(), fieldType1);//L'auteur
        Field fieldContenu = new Field("contenu", article.toString(), fieldType2);//Et tous le contenu de l'article
        document.add(fieldContenu);//On ajoute ces champs au document
        document.add(fieldTitre);
        document.add(fieldAuthor);
        return document;
    }

    //Cette méthode permet d'indexer une liste d'article.
    //Elle prend en entrée une liste d'article, et indexe chaque Article
    public void indexFile(List<Article> liste) {
        try {
            for (Article article : liste) {//On parcourt la liste des articles
                writer.addDocument(articleToDocument(article)); //On convertit chaque article en Document et on l'ajoute à l'index en utilisant le Writer    
            }
            writer.commit();//A la fin on valide les modifications
            //System.out.println("writer.comit"+writer.getDirectory());
            writer.close();
        } catch (IOException ex) {
            System.out.println("Impossible d'indexer ce fichier");
        }
    }

    //Cette méthode permet d'executer une requete 
    //Elle prend en entree le champ sur lequel il faut faire la requete et le terme à chercher
    //Elle donne en sortie un TopDocs
    public TopDocs requete(String champ, String valeur) {
        try {
            reader = DirectoryReader.open(fsDirectory);// on cree le DirectoryReader
            indexSearcher = new IndexSearcher(reader);//On cree l'IndewSearcher
        } catch (IOException ex) {
            System.out.println("Impossible d'acceder à l'index");
        }
            
        TopDocs docs = null;//on initialise le resultat
        Query query = null;//On initialise la requete
        try {
            QueryParser parser = new QueryParser(champ, analyzer);//On cree un QueryParser en utilisant e champ donné et l'Analyzer
            query = parser.parse(valeur); //On cree la requete en utilisant le Queryparser
        } catch (ParseException ex) {
            System.out.println("Requête invalide");
        }
        if (query != null) {
            try {
                       
                docs = indexSearcher.search(query, 1000);//on execute la requete avec une limite de 1000 resultats
            } catch (IOException ex) {
                System.out.println("Index inexistant");
            }
        }
        return docs;
    }

    
    //Cette methode premet de donner les fréquences d'une expression sur un champ.
    //Elle prend en entrée le terme et le champ
    public String frequence(String champ, String term) {
        try {
            reader = DirectoryReader.open(fsDirectory);// on cree le DirectoryReader
            indexSearcher = new IndexSearcher(reader);//On cree l'IndewSearcher
        } catch (IOException ex) {
            System.out.println("Impossible d'acceder à l'index");
        }
        String result = "";//On initialise le resultat
        try {
            
            Term termInstance = new Term(champ, term.toLowerCase());//on cree un objet Terme avec le champ et le mot-clé donnés
            long termFreq = reader.totalTermFreq(termInstance);//on recherche le nombre d'occurrence total de l'expression
            long docCount = reader.docFreq(termInstance);//on cherche le nombre de documents dans lequel l'expression est présente
            result = "Expression Recherchée: " + term.toLowerCase() + "\n Nombre d'articles ou Présent " + docCount + "\n Nombre d'occurence Total: " + termFreq;           
        } catch (IOException ex) {
            System.out.println("Requête invalide");
        }
        return result;
    }

    
    //Cette methode permet de trouver les termes les plus fréqents sur un champ donné
    //Elle prend en entreé le champ, et le nombre de termes à rexchercher
    public String frequences(String champ, int limit) {
        try {
            reader = DirectoryReader.open(fsDirectory);// on cree le DirectoryReader
            indexSearcher = new IndexSearcher(reader);//On cree l'IndewSearcher
        } catch (IOException ex) {
            System.out.println("Impossible d'acceder à l'index");
        }
        String result = "";
        DocFreqComparator cmp = new HighFreqTerms.DocFreqComparator();
        try {
            
            org.apache.lucene.misc.TermStats[] stat = HighFreqTerms.getHighFreqTerms(reader, limit, champ, cmp);
            int i = 0;
            for (org.apache.lucene.misc.TermStats ts : stat) {
                result = result + " term " + ts.termtext + " freq doc " + ts.docFreq + " freq tot " + ts.totalTermFreq + "\n";
                i++;
            }
        } catch (Exception ex) {
            System.out.println("impossible d'acceder à l'index");;
        }
        return result;
    }

    //Cette méthode permet d'afficher le resultat d'une requete. Elle prend en entrée un objet TopDocs representant le resultat,
    public String resultatRequete(TopDocs docs, int limit) {
        try {
            reader = DirectoryReader.open(fsDirectory);// on cree le DirectoryReader
            indexSearcher = new IndexSearcher(reader);//On cree l'IndewSearcher
        } catch (IOException ex) {
            System.out.println("Impossible d'acceder à l'index");
        }
        String result = "";
        ScoreDoc[] scoreDocArray = docs.scoreDocs;
        int i = 0;
        for (ScoreDoc scoredoc : scoreDocArray) {
            // Retourne le document et affiche les détails
            try {
                Document doc = indexSearcher.doc(scoredoc.doc);
                if (i < limit) {
                    result = result + i + " Titre " + doc.get("titre") + " Auteur " + doc.get("author") + "\n";
                }
                i++;
            } catch (IOException e) {
                System.out.println("Impossible d'accéder aux resultats de la requete");
            }
        }
        return result;
    }
}
