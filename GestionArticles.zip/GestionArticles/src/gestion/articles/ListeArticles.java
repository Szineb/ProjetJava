/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion.articles;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Observable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

/**
 *
 * @author Nico
 */
public class ListeArticles {
    private ArrayList<Article> listeArticles;

    public ListeArticles() {
        this.listeArticles = new ArrayList();
    }
    
    public void bidon(){
        URL url = null;
        try {
            url = new URL("https://www.google.fr/?gfe_rd=cr&ei=ZhVVWPOFH4rf8geawbCwCw");
        } catch (MalformedURLException ex) {
            Logger.getLogger(ListeArticles.class.getName()).log(Level.SEVERE, null, ex);
        }
        for(int i = 0; i <100 ; i++)
        {
            GestionArticles.data.add(new Article("Title"+i, "Description"+i, LocalDate.now(), "RSS"+i, "Author"+i, url, i));
            GestionArticles.dataCopie.add(new Article("Title"+i, "Description"+i, LocalDate.now(), "RSS"+i, "Author"+i, url, i));
        }
          
          System.out.println("BIDON****");
    }
    
    
    public void importer(String fileName) throws FileNotFoundException , IOException
    {
         String title = "";
         String description = "";
         String datePublication = "";
         String rss = "";
         String author = "";
         String link = "";
         String inter = "";
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(fileName));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ListeArticles.class.getName()).log(Level.SEVERE, null, ex);
        }
        // read file line by line
        String line = null;
        Scanner scanner = null;
        int index = 0;
        int i = 0;
        System.out.println("Archivo importado");
        System.out.println("=================================");
        while ((line = reader.readLine()) != null) {
            //Article art = new Article();
            scanner = new Scanner(line);
            scanner.useDelimiter(" ");
            while (scanner.hasNext()) {
                String data = scanner.next();
                if (index == 0) {
                    title = data;
                } else if (index == 1) {
                    description = data;
                } else if (index == 2) {
                    datePublication = data;
                } else if (index == 3) {
                    rss = data;
                } else if (index == 4) {
                    author = data;
                } else if (index == 5) {
                    link = data;
                } else if (index == 6) {
                    inter = data;
                } else {
                    System.out.println("invalid data::" + data);
                }
                index++;
            }
          
            index = 0;
            i++;
        }
        reader.close();

    }

   
}
