/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion.articles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Observable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

/**
 *
 * @author Nico
 */
public class ListeArticles {

    //cette méthode permet de Convertir une entree de type String en un format de date 
    //Elle prend en entrée une chane de caracteres et donne en sortie un objet Zoneddatetime
    private ZonedDateTime convertTexteToDate(String dateString) throws ParseException {
        //On créé un formatter de date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);
        ZonedDateTime dateUTC = null;//dateUTC represente le resultat de la méthode
        try {
            LocalDateTime date = LocalDateTime.parse(dateString, formatter);//On convertit la date sous forme de chaines de String en LocalDateTime
            ZoneId utc = ZoneId.of("GMT");
            dateUTC = ZonedDateTime.of(date, utc);//On convetit le LocalDateTime en ZonedDateTime
        } catch (Exception e) {
            System.out.println("Format de la date incorrect" + dateString);
        }
        return dateUTC;
    }
    
    //Cette methode permet de convertir une ZonedDateTime en date textuelle
    private String convertDateToTexte(ZonedDateTime date) throws ParseException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);
        String texte = formatter.format(date);
        return texte;
    }

    //Cette methode permet de supprimer les cotes qu'il y'a au niveau des données de chaque ligne et chaque champ du fichier .csv
    private String supprimerCotes(String chaine) {
        if (chaine.length() > 2) {
            chaine = chaine.substring(1, chaine.length() - 1);//On supprime le premier et le dernier caractères qui sont les cotes
        }
        return chaine;
    }

    
    //Cette methode permet de transformer une ligne d'un fichier CSV en objet Article
    private Article lineToArticle(String ligne) {
        Scanner scanner = new Scanner(ligne);
        scanner.useDelimiter("\t"); // On recupere la premiere chaine de caracteres. On s'arrête quand on croise une tabulation
        int index = 0;
        String title = "", description = "", rss = "", author = ""; 
        ZonedDateTime datePublication = null;
        URL link = null;
        int inter = 0;
        while (scanner.hasNext()) { //On repete jusqu'a recuperer toutes les portions de la ligne
            String data = scanner.next();
            data = supprimerCotes(data); //Quand on recupere une portion on supprime les cotes
            if (index == 0) { // Si c'est la portion 0, alors c'est le champ "titre";
                title = data;
            } else if (index == 1) {// Si c'est la portion 1, alors c'est le champ "description"
                description = data;
            } else if (index == 2) {// Si c'est la portion 2, alors c'est le champ "date". 
                try {
                    datePublication = convertTexteToDate(data);//On convertit alors la chaine de caracteres en date
                } catch (ParseException ex) {
                    System.out.println("Impossible de convertir");;
                }
            } else if (index == 3) {
                rss = data;
            } else if (index == 4) {
                author = data;
            } else if (index == 5) {
                try {
                    link = new URL(data);
                } catch (MalformedURLException ex) {
                    System.out.println("URL invalide");
                }
            } else if (index == 6) {
                try {
                    inter = Integer.parseInt(data);
                } catch (Exception e) {
                    System.out.println("Conversion impossible");
                    inter = 0;
                }

            } else {
                System.out.println("invalid data::" + data);
            }
            index++;
        }
        Article article;
        article = new Article(title, description, datePublication, rss, author, link, inter);//On cree un objet article avec les donnees recuperees
        return article;
    }

    //Cette méthode permet de charger un fichier CSV dans une liste d'objets Article
    //Elle prend en entrée le fichier à importer et retourne une liste d'articles correspondant au contenu du fichier
    public List<Article> importer(File fileName) throws FileNotFoundException, IOException {
        ArrayList<Article> liste = new ArrayList<>();//On initialise la liste
        try {
            Scanner scanner = new Scanner(fileName); // On utilise un objet scanner pour recuperer les lignes du fichier
            scanner.nextLine();//On lit la premiere ligne
            while (scanner.hasNextLine()) {//on continue jusq'a la fin du fichier
                String line = scanner.nextLine();//on lit une ligne
                Article art = lineToArticle(line);//On convertit la ligne en objet Article
                liste.add(art);//on l'ajoute à la liste
            }
            scanner.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Impossible d'ouvrir le fichier");
        }
        return liste;
    }

    //Cette methode permet de tranformer un objet article en une ligne de fichier CSV 
    private String ArticleToLine(Article art) {
        String line = "";
        String datepub = "";
        try {
            datepub = convertDateToTexte(art.getDatePublication());//On convertit le champ date de publication de type ZonedDateTime en String
        } catch (ParseException ex) {
            System.out.println("Impossible de covertir la date");
        }
        //on cree la ligne en utilisant des tabulations pour separer les camps
        line = art.getTitle() + "\t" + art.getDescription() + "\t" + datepub + "\t" + art.getRss() + "\t" + art.getAuthor() + "\t" + art.getLink() + "\t" + art.getInter();
        return line;
    }

    
    //Cette méthode permet de creer un fichier CSV a partir d'une liste d'articles
    //Elle prend en entree la liste des articles et le dossier dans lequel devra se faire la sauvegarde
    public void exporter(List<Article> liste, File dossier) {
        File file = new File(dossier, "Export" +".csv");
        if (file.canWrite()) {//On verifie que le fichier est bien créé
            for (int i = -1; i < liste.size(); i++) {
                String content = "";
                if (i == -1) {//A la premiere itération on insere dans le fichier les entetes des champs
                    content = "title" + "\t" + "description" + "\t" + "date" + "\t" + "rss" + "\t" + "author" + "\t" + "link";
                } else {//Pour les autres iterations, on insere l'article
                    content = "\n" + ArticleToLine(liste.get(i));
                }
                try {
                    FileWriter fw = new FileWriter(file, true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(content);
                    bw.close();
                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Impossible d'ecrire");
        }
    }
    
    private String dateCourante(){//Cette methode renvoie un String representant la date et l'heure courante. cette methode est utilisee pour nommer les fichiers exportés
        
        return "_"+new Date()+"_";
    }

}
