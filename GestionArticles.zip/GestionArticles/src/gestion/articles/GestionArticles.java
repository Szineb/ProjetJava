/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion.articles;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 *
 * @author pesawado
 */
public class GestionArticles extends Application {
    //Creation du TableView
    private TableView tableView = new TableView();
    ArrayList<Article> liste = new ArrayList<>();
    
    public static ObservableList<Article> data = FXCollections.observableArrayList();
    public static ObservableList<Article> dataCopie = FXCollections.observableArrayList();
    
    private final int FRAME_WIDTH = 1200;
    private final int FRAME_HEIGTH = 600;
    private final String TITLE = "*******GESTION ET ANALYSE DES ARTICLES DE PRESSE*******";
    
    private TextField filtreTitre = new TextField();
    private TextField filtreDescription = new TextField();
    private TextField filtreAuteur = new TextField();
    private TextField filtreGlobal = new TextField();
    
    @Override
    public void start(Stage primaryStage) {
        MenuBar menuBar = new MenuBar();
        Menu menuImporter = new Menu("Importer");
        Menu menuExporter = new Menu("Exporter");
        Menu menuTrier = new Menu("Trier");
        
        
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choix du fichier à importer");
        File homeDir = new File(System.getProperty("user.home"));
        fileChooser.setInitialDirectory(homeDir);
        fileChooser.getExtensionFilters().addAll( new ExtensionFilter("CSV Files" , "*.csv"));
        DirectoryChooser dirChooser = new DirectoryChooser();
        dirChooser.setTitle("Dossier d'enregistrement du fichier");
        dirChooser.setInitialDirectory(homeDir);
        
        
        menuBar.getMenus().addAll(menuImporter,menuExporter, menuTrier);
        Button boutonImporter = new Button("Importer...");   
        Button boutonExporter = new Button("Exporter...");
        BorderPane root = new BorderPane();
        //filtreAuteur.setMaxWidth(100);
        //filtreDescription.setMaxWidth(100);
        //filtreGlobal.setMaxWidth(100);
        //filtreTitre.setMaxWidth(100);
        Label labelFiltreTitre = new Label("FILTRE/TITRE");
        Label labelFiltreDescription = new Label("FILTRE/DESCRIPTION");
        Label labelFiltreAuteur = new Label("FILTRE/AUTEUR");
        Label labelFiltreGlobal = new Label("FILTRE GENERAL");
        TilePane conteneurHaut = new TilePane();
        TilePane conteneurHaut1 = new TilePane();
        GridPane conteneurHaut2 = new GridPane();
        conteneurHaut1.getChildren().addAll(menuBar);
        conteneurHaut2.add(boutonImporter,0,0,1, 2);
        conteneurHaut2.add(boutonExporter,1,0, 1, 2);
        conteneurHaut2.add(labelFiltreTitre,2,0);
        conteneurHaut2.add(filtreTitre,2,1);
        conteneurHaut2.add(labelFiltreDescription,3,0);
        conteneurHaut2.add(filtreDescription,3,1);
        conteneurHaut2.add(labelFiltreAuteur,4,0);
        conteneurHaut2.add(filtreAuteur,4,1);
        conteneurHaut2.add(labelFiltreGlobal,5,0);
        conteneurHaut2.add(filtreGlobal,5,1);
       
        conteneurHaut.getChildren().addAll(conteneurHaut1, conteneurHaut2);
        
        
        TableColumn numCol = new TableColumn("N°"); 
        TableColumn titleCol = new TableColumn("TITLE");
        TableColumn descriptionCol = new TableColumn("DESCRIPTION");
        TableColumn datePublicationCol = new TableColumn("DATE");
        TableColumn rssCol = new TableColumn("RSS");
        TableColumn authorCol = new TableColumn("AUTEUR");
        TableColumn linkCol = new TableColumn("LINK");
        TableColumn interCol = new TableColumn("INTER");
        //Association des noms de colonnes à des champs de la classe Article
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        datePublicationCol.setCellValueFactory(new PropertyValueFactory<>("datePublication"));
        rssCol.setCellValueFactory(new PropertyValueFactory<>("rss"));
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        linkCol.setCellValueFactory(new PropertyValueFactory<>("link"));
        interCol.setCellValueFactory(new PropertyValueFactory<>("inter"));
        
        numCol.setMinWidth(FRAME_WIDTH * 2 / 100);
        titleCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        descriptionCol.setMinWidth(FRAME_WIDTH* 35 / 100);
        datePublicationCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        rssCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        authorCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        linkCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        interCol.setMinWidth(FRAME_WIDTH* 10 / 100);
        FlowPane conteneurBas = new FlowPane();
        Label labelBas = new Label("STATISTIQUES");
        conteneurBas.getChildren().add(labelBas);
        
        tableView.getColumns().addAll(numCol, titleCol, descriptionCol, datePublicationCol,rssCol,authorCol, linkCol, interCol  );
        tableView.setItems(data);
        root.setTop(conteneurHaut);
        root.setCenter(tableView);
        root.setBottom(conteneurBas);
        Scene scene = new Scene(root, FRAME_WIDTH, FRAME_HEIGTH );
        
        
        
        //Ecouteurs
        
        boutonImporter.setOnMouseClicked(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                
                File selectedFile = fileChooser.showOpenDialog(primaryStage);
                
                    if (selectedFile != null){
                    
                    }
            }
        });
        
        boutonExporter.setOnMouseClicked(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                
                File selectedFile = dirChooser.showDialog(primaryStage);
                
                    if (selectedFile != null){
                    
                    }
            }
        });
        
        
        
        
        filtreTitre.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); //To change body of generated methods, choose Tools | Templates.
            }    
        });
        filtreAuteur.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); //To change body of generated methods, choose Tools | Templates.
            }    
        });
        filtreDescription.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); //To change body of generated methods, choose Tools | Templates.
            }    
        });
        filtreGlobal.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateData(); //To change body of generated methods, choose Tools | Templates.
            }    
        });
        
        
        
        primaryStage.setTitle(TITLE);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         ListeArticles l = new ListeArticles();
        l.bidon();
        launch(args);
        
        
    }
    
    
    //Creation des écouteurs
    
   private void updateData(){
       data.clear();
        for (Article a : dataCopie) {
            if (matchesTitle(a) && matchesAuteur(a) && matchesDescription(a) && matchesGlobal(a)) {
                data.add(a);
            }
        }
        // Must re-sort table after items changed
        //reapplyTableSortOrder();
   }
   
    private boolean matchesTitle(Article a) {
        String filterString = filtreTitre.getText();
        if (filterString == null || filterString.isEmpty()) {            
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getTitle().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        } 
        return false; // Does not match
    }
    
    private boolean matchesDescription(Article a) {
        String filterString = filtreDescription.getText();
        if (filterString == null || filterString.isEmpty()) {            
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getDescription().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        } 
        return false; // Does not match
    }
    
    private boolean matchesAuteur(Article a) {
        String filterString = filtreAuteur.getText();
        if (filterString == null || filterString.isEmpty()) {            
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.getAuthor().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        } 
        return false; // Does not match
    }
    
    private boolean matchesGlobal(Article a) {
        String filterString = filtreGlobal.getText();
        if (filterString == null || filterString.isEmpty()) {            
            return true;
        }
        String lowerCaseFilterString = filterString.toLowerCase();
        if (a.toString().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        } 
        return false; // Does not match
    }
    
}
